package appcocina.implementacionfundamentosingsw;

import java.util.ArrayList;

public class ContUsuario {
    ArrayList<Usuario> usuarios = new ArrayList<Usuario>();

    public void agregarUsuario(String nombre, int cedula, String fecha, String direccion, String contrasena, String tipo ){
        usuarios.add(new Usuario(nombre,cedula,fecha,direccion,contrasena,tipo));
    }
    public Usuario buscarUsuario(String nombre){
        for(Usuario u:usuarios){
            if(u.getNombre().equals(nombre))
                return u;
        }
        return null;
    }

    public Usuario buscarContrasena(String contrasena){
        for(Usuario u:usuarios){
            if(u.getContraseña().equals(contrasena))
                return u;
        }
        return null;
    }

}
