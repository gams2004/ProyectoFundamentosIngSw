package appcocina.implementacionfundamentosingsw;


import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Scanner;

public class ManejadorArchivos {

    public ContUsuario leerUsuarios() throws IOException {
        ContUsuario contUsuario = new ContUsuario();
        InputStreamReader input = new InputStreamReader(new FileInputStream("Usuarios.txt"));
        BufferedReader fa = new BufferedReader(input);
        String cad = fa.readLine();
        while (!cad.equalsIgnoreCase("FIN")) {
            Scanner del = new Scanner(cad).useDelimiter("%");
            String nombre = del.next();
            int cedula = del.nextInt();
            String fecha = del.next();
            String direccion = del.next();
            String contrasena = del.next();
            String tipo = del.next();
            cad = fa.readLine();
            contUsuario.agregarUsuario(nombre, cedula, fecha, direccion, contrasena, tipo);
        }
        return contUsuario;
    }

}

