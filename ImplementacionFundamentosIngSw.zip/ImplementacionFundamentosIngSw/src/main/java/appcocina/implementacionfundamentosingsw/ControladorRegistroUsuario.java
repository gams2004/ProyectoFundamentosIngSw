package appcocina.implementacionfundamentosingsw;

import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXTextArea;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.Objects;

public class ControladorRegistroUsuario {
    @FXML
    private JFXButton btn_registrarse;

    @FXML
    private TextField Usuario;

    @FXML protected void registrarse(ActionEvent event) throws IOException {
        if(event.getSource() == btn_registrarse){
            try {
                Stage stage = (Stage) Usuario.getScene().getWindow();
                stage.close();
                Stage profesorStage = new Stage();
                Parent root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("InterfazLogin.fxml")));
                profesorStage.setTitle("Menu.");
                profesorStage.setScene(new Scene(root));
                profesorStage.show();
            } catch (Exception ignored){}
        }

    }
}


