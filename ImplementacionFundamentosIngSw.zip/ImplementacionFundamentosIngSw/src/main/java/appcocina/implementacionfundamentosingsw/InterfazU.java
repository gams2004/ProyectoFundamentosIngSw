package appcocina.implementacionfundamentosingsw;

import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXRadioButton;
import com.jfoenix.controls.JFXTextArea;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Pane;


public class InterfazU {

    @FXML
    private JFXButton abrir;

    @FXML
    private AnchorPane ap_panes;

    @FXML
    private JFXButton atras;

    @FXML
    private JFXButton atras1;

    @FXML
    private JFXButton atras11;

    @FXML
    private JFXButton atras1111;

    @FXML
    private JFXButton atras11111;

    @FXML
    private JFXButton btn_calServ, btn_consConfiguracion;

    @FXML
    private JFXButton btn_consRut;

    @FXML
    private JFXButton btn_crearCom;

    @FXML
    private JFXButton btn_prgRuta;

    @FXML
    private JFXButton btn_progRut;

    @FXML
    private JFXButton btn_upValCom, btn_buscarRecetas;

    @FXML
    private JFXButton btn_upValCom1;

    @FXML
    private JFXButton btn_Recetas;

    @FXML
    private JFXButton cerrar;

    @FXML
    private Pane pnl_calServ;

    @FXML
    private Pane pnl_consRut;

    @FXML
    private Pane pnl_crearCom;

    @FXML
    private Pane pnl_menu;

    @FXML
    private Pane pnl_opacidad;

    @FXML
    private Pane pnl_progRut;

    @FXML
    private Pane pnl_recetas;

    @FXML
    private JFXRadioButton rbtn_comNeg;

    @FXML
    private JFXRadioButton rbtn_valNeg;

    @FXML
    private JFXRadioButton rbtn_comPos;

    @FXML
    private JFXRadioButton rbtn_valPos;

    @FXML
    private JFXTextArea txa_comVal;

    @FXML
    private JFXTextArea txa_coment;

    @FXML
    private JFXTextArea txa_consRut;

    @FXML
    private JFXTextArea txa_progRut, txa_valCom;

    @FXML
    private TextField txf_calID;

    @FXML
    private TextField txf_comID;

    @FXML
    private TextField txf_comID11;

    @FXML
    private TextField txf_crearComBus;

    @FXML
    private TextField txf_crearComID;

    @FXML
    private TextField txf_crearComRut;

    @FXML
    private TextField txf_progHL;

    @FXML
    private TextField txf_progLL;

    @FXML
    private TextField txf_progNum;



        @FXML protected void onMenuButtonClick(ActionEvent event) {
            if(event.getSource() == abrir){
                pnl_opacidad.toFront();
                pnl_menu.toFront();
            }
            if(event.getSource() == cerrar){
                pnl_opacidad.toBack();
                pnl_menu.toBack();
            }
            if(event.getSource()== btn_Recetas ){
                ap_panes.toFront();
                pnl_recetas.toFront();
            }
            if(event.getSource() == btn_calServ){
                ap_panes.toFront();
                pnl_calServ.toFront();
            }
            if(event.getSource() == btn_buscarRecetas){
                ap_panes.toFront();
                pnl_consRut.toFront();
            }
            if(event.getSource() == btn_consConfiguracion){
                ap_panes.toFront();
                pnl_consRut.toFront();
            }
            if(event.getSource()==btn_crearCom){
                ap_panes.toFront();
                pnl_crearCom.toFront();
            }
            if(event.getSource() == btn_progRut){
                ap_panes.toFront();
                pnl_progRut.toFront();
            }

            if(event.getSource()== atras){
                ap_panes.toBack();
            }
            if(event.getSource()== atras1){
                ap_panes.toBack();
            }
            if(event.getSource()== atras11){
                ap_panes.toBack();
            }
            if(event.getSource()== atras1111){
                ap_panes.toBack();
            }
            if(event.getSource()== atras11111){
                ap_panes.toBack();
            }
            /////////////////////////////////////////
            if(event.getSource() == btn_upValCom){
                try{
                    if(txf_comID == null){
                        throw new Exception();
                    }
                    else{

                    }
                }catch(Exception e){
                    txa_valCom.setText("ID incorrecto");
                }


            }














        }

}
