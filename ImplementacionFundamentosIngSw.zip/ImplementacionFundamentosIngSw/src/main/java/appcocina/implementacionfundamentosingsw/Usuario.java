package appcocina.implementacionfundamentosingsw;

public class Usuario {

    private String nombre;
    private Integer numeroCedula;
    private String fechaNacimiento;
    private String direccion;
    private String contraseña;
    private String tipo;


    public Usuario(String nombre, Integer numeroCedula, String fechaNacimiento, String direccion, String contraseña, String tipo){
        this.nombre = nombre;
        this.numeroCedula = numeroCedula;
        this.fechaNacimiento = fechaNacimiento;
        this.direccion = direccion;
        this.contraseña = contraseña;
        this.tipo = tipo;
    }

    public Usuario() {

    }

    public Usuario(String nombre) {
    }


    public void setNombre(String nombre){
        this.nombre = nombre;
    }

    public void setNumeroCedula(Integer numeroCedula){
        this.numeroCedula= numeroCedula;
    }

    public void setFechaNacimiento(){
        this.fechaNacimiento=fechaNacimiento;
    }

    public void setDireccion(String direccion){
        this.direccion=direccion;
    }

    public String getContraseña(){
        return contraseña;
    }
    public void setContraseña(String contraseña){
        this.contraseña=contraseña;
    }

    public String getNombre(){
        return nombre;
    }

    public Integer getNumeroCedula(){
        return numeroCedula;
    }

    public String getFechaNacimiento(){
        return fechaNacimiento;
    }

    public String getDireccion(){
        return direccion;
    }


    public String getTipo() {
        return this.tipo;
    }
}
